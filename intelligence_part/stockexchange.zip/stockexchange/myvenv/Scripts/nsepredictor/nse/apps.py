from django.apps import AppConfig


class NseConfig(AppConfig):
    name = 'nse'
