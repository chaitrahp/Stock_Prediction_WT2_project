from flask import Flask,request,jsonify,make_response,session,render_template
from flask_bootstrap import StaticCDN
from flask import Response
from wtforms import TextField, Form
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin
import requests
import json
import sys
import re
import decimal

app = Flask(__name__)


app.config['CORS_HEADERS'] = 'Content-Type'




@app.route('/refresh', methods=['GET'])
def companies():
    #form = SearchForm(request.form)
    return render_template("periodic_refresh.html")

@app.route('/periodic',methods=['POST'])
def periodic():
    comp  = request.form['comp']
    response_data = requests.get('https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=' + comp + '&interval=1min&apikey=98X17VWSVIYC29CO')
    #print(response_data)
    val = response_data.json()
    l1 = []
    for i in val:
        l1.append(i)
    #print(l1[0],l1[1])
    l =[]
    for i in val[l1[1]]:
        l.append(i)
    #print(l)
    #print("*************",val[l1[1]][l[0]]["1. open"])

    #print("value",val["Time Series (1min)"],type(val))
    return jsonify({"a1":val["Meta Data"]['2. Symbol'],"a2":val[l1[1]][l[0]]['1. open'],"a3":val[l1[1]][l[0]]['2. high'],"a4":val[l1[1]][l[0]]['3. low'],"a5":val[l1[1]][l[0]]['4. close'],"a6":val[l1[1]][l[0]]['5. volume']})
    
if __name__ == '__main__':
    app.run(debug=True)
