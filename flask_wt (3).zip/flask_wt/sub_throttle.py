from flask import Flask,request,jsonify,make_response,session,render_template
from flask_bootstrap import StaticCDN
from flask import Response
from wtforms import TextField, Form
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin
import requests
import json
import sys
import re
import decimal

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:''@localhost/stock_exchange'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['CORS_HEADERS'] = 'Content-Type'

db =SQLAlchemy(app)

class stock(db.Model):
    __tablename__ = 'stock'
    id = db.Column(db.Integer,primary_key = True)
    company = db.Column(db.VARCHAR(10))
    equity = db.Column(db.VARCHAR(2))
    open_price = db.Column(db.VARCHAR(10))
    high_price = db.Column(db.VARCHAR(10))
    low_price = db.Column(db.VARCHAR(10))
    close_price = db.Column(db.VARCHAR(10))
    last_price = db.Column(db.VARCHAR(10))
    prev_close = db.Column(db.VARCHAR(10))
    total_trade_quantity = db.Column(db.VARCHAR(10))

    total_trade_volume = db.Column(db.VARCHAR(20))
    total_trades  = db.Column(db.VARCHAR(10))
    isin = db.Column(db.VARCHAR(12))
    db.create_all()
    def __init__(self,company,equity,open_price,high_price,low_price,close_price,last_price,prev_close,total_trade_quantity,total_trade_volume,total_trades,isin):
        self.company = company
        self.equity = equity
        self.open_price = open_price
        self.high_price = high_price
        self.low_price = low_price
        self.close_price = close_price
        self.last_price = last_price
        self.prev_close = prev_close
        self.total_trade_quantity = total_trade_quantity
        self.total_trade_volume = total_trade_volume
        self.total_trades = total_trades
        self.isin = isin

stock_data = stock.query.all()
company = []
equity = []
open_price = []
high_price = []
low_price = []
close_price = []
last_price = []
prev_close = []
total_trade_quantity = []
total_trade_volume = []
total_trades = []
isin = []
for stock in stock_data:
    company.append(stock.company)
    equity.append(stock.equity)
    open_price.append(stock.open_price)
    high_price.append(stock.high_price)
    low_price.append(stock.low_price)
    close_price.append(stock.close_price)
    last_price.append(stock.last_price)
    prev_close.append(stock.prev_close)
    total_trade_quantity.append(stock.total_trade_quantity)
    total_trade_volume.append(stock.total_trade_volume)
    total_trades.append(stock.total_trades)
    isin.append(stock.isin)


#class SearchForm(Form):
 #   autocomp = TextField('Insert City', id='city_autocomplete')

@app.route('/')
def homepage():
    return render_template("index1.html")
    #requests.get("templates/index.html")


@app.route('/_autocomplete', methods=['GET'])
def autocomplete():
    term = request.args.get('comp')
    return Response(json.dumps(company), mimetype='application/json')


@app.route('/company_data',methods=['POST'])
def company_data():
    comp  = request.form['comp']
    print("data :",comp,type(comp))
    
    for i in range(len(company)):
        if (comp == company[i]):
            print(company[0],type(company[0]))
           # all ={"comp":company[i],"equity":equity[i],"open_price":open_price[i],"close_price":close_price[i],"ttq":total_trade_quantity[i],"ttv":total_trade_volume[i],"tt":total_trades[i],"isin":isin[i]}
            return jsonify({"comp":company[i],"equity":equity[i],"open_price":open_price[i],"close_price":close_price[i],"ttq":total_trade_quantity[i],"ttv":total_trade_volume[i],"tt":total_trades[i],"isin":isin[i]})
    return jsonify({'error':'missing data'})


@app.route('/sub_throttle', methods=['GET'])
def sub_throttle():
    #form = SearchForm(request.form)
    return render_template("sub.html")


@app.route('/refresh', methods=['GET'])
def refresh():
    #form = SearchForm(request.form)
    return render_template("periodic_refresh.html")

@app.route('/periodic',methods=['POST'])
def periodic():
    comp  = request.form['comp']
    response_data = requests.get('https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=' + comp + '&interval=1min&apikey=98X17VWSVIYC29CO')
    #print(response_data)
    val = response_data.json()
    l1 = []
    for i in val:
        l1.append(i)
    #print(l1[0],l1[1])
    l =[]
    for i in val[l1[1]]:
        l.append(i)
    #print(l)
    #print("*************",val[l1[1]][l[0]]["1. open"])

    #print("value",val["Time Series (1min)"],type(val))
    return jsonify({"a1":val["Meta Data"]['2. Symbol'],"a2":val[l1[1]][l[0]]['1. open'],"a3":val[l1[1]][l[0]]['2. high'],"a4":val[l1[1]][l[0]]['3. low'],"a5":val[l1[1]][l[0]]['4. close'],"a6":val[l1[1]][l[0]]['5. volume']})

#Login with
@app.route('/facebook',methods=['GET'])
def facebook():
    requests.get("https://www.facebook.com")

@app.route('/twitter',methods=['GET'])
def twitter():
    requests.get("https://twitter.com/login?lang=en")

@app.route('/google',methods=['GET'])
def google():
    requests.get("https://accounts.google.com/AccountChooser?service=lso")

@app.route('/instagram',methods=['GET'])
def instagram():
    requests.get("https://www.instagram.com/accounts/login/")
#Google font
@app.route('/googlefonts',methods=['GET'])
def googlefonts():
    requests.get("https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900")

if __name__ == '__main__':
    app.run(debug=True)
